package main.apicircuit;

/**
 * Created by IAnastas on 1/25/2016.
 */
public abstract class UnaryLogicalExpression extends Element
{
    protected Element element;
    public abstract boolean getValue();

    public Element getElement()
    {
        return element;
    }
}
