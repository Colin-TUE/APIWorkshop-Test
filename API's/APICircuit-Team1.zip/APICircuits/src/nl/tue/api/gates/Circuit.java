/**
 * 
 */
package nl.tue.api.gates;

import java.util.ArrayList;
import java.util.List;

/**
 * @author IMikovsk
 *
 */
public class Circuit {

	List<Gate> gates = new ArrayList<>();
	GateFactory factory = new GateFactory(); 
	
}
