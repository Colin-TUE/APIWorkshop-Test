/**
 * 
 */
package nl.tue.api.gates;

/**
 * @author IMikovsk
 *
 */
public interface EvaluatonStrategy<T> {

	public T eval();
}
