/**
 * 
 */
package nl.tue.api.gates;

/**
 * @author IMikovsk
 *
 */
public class Evaluator<T>  {
	
	public T eval(T op1, T op2){
		T result = null;
		
		if(op1 instanceof Boolean && op2 instanceof Boolean){
			
		}
		
		return result;
	}
}
