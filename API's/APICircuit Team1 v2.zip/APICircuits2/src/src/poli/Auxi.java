/**
 * 
 */
package src.poli;

/**
 * @author IMikovsk
 *
 */
public class Auxi {

}
