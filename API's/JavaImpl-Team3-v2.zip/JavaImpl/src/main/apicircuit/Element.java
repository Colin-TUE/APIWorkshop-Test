package main.apicircuit;

/**
 * Created by IAnastas on 1/25/2016.
 */
public abstract class Element
{
    public abstract boolean getValue();
    public abstract double getDoubleValue();
}
