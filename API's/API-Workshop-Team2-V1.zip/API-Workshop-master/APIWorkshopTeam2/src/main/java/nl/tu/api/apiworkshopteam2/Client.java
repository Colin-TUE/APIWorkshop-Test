package nl.tu.api.apiworkshopteam2;

/**
 * @author CLambrec
 * @version 1.0
 * @created 25-Jan-2016 12:47:41
 */
public class Client {

	private AbstractFactory factory;
	private CircuitTarget circuits;

	public Client(){

	}

	public void finalize() throws Throwable {

	}
}//end Client